CREATE PROCEDURE p(IN tmp_sno INT(10), IN pro_name CHAR(10))
  begin
select name into pro_name from users1 where id=tmp_sno;
end;
